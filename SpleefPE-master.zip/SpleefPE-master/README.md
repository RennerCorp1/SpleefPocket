# SpleefPE
Spleef for PocketMine with effect blocks

### THIS PLUGIN ISN'T FINISHED YET. IT WILL CRASH YOUR SERVER WHEN UNLOADING THE LEVEL DUE TO LEVEL RESET

## Usage
```php
/spleef <join|leave|addworld <name>|removeworld <name>|spawns <add|remove|list|tp>>

before anyone can join a map, you have to do:

/spleef addworld <worldname>

You have to provide an existing map

then, go to the world and add as many spawns as you want. That many players can join the match later

/spleef spawns add

After that your map is ready to go.

To join do:

/spleef join <mapname>

If you only have 1 map you can also do /spleef join, else /spleef join will let you join a random map
```

## Notes

This plugin was coded and is maintained by thebigsmileXD of the Imagical Corporation. This is not a plugin for everyone, this is a plugin for our intended use. Hopefully you find it useful too.
